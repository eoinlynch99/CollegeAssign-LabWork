package com.assignment.OO;

import java.util.*;

public class FileSearch 
{

	public void FileScanner(ArrayList scanner1 )
	{
		if (scanner1.contains("ruin")) 
		{
		    System.out.println("Word found");
		} 
		else 
		{
		    System.out.println("Word not found");
		}

	}
}
