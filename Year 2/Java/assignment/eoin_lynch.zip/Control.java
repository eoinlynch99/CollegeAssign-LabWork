/*
Author: Eoin Lynch
Date: April 2018
Project: OO Assignment
*/

package com.assignment.OO;

public class Control {

	public static void main(String[] args) {
	}

}
