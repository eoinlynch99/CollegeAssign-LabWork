################## README ####################
In this assignment I was able to convert a text
file into an ArrayList. This was then used to
try to search a file for a word. The user would
then be told if the keyword they were searching for,
ruin, was included in the text file.