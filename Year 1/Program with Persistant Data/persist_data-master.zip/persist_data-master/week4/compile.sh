gcc random.c -o random && \
gcc read_random.bin.c -o read_random && \
gcc read_ramdom_array.c -o read_ramdom_array && \
gcc 3_10_0.c -o 3_10_0 && \
gcc copy.c -o copy && \
gcc read.c -o read && \
gcc compare.c -o compare
