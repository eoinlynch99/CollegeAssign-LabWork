our encryption algorithm will be as follows:
Load file into ram as a character array
if sizeof array is odd, subtract 1
while i<sizeof array swap the ith and i+1th elements and add 2 to i
tack on an sbl extension
