
#Week 5
#Lab4
Exercises with files using structs.<br>
Write all these C programs such that the programs can accept input from the
user in relation to a student credit union account. The struct will be called
creditUnion and the variable will be DIT
To open an account you are required to provide 2 evidences of postal address1
,
your passport for photographic id and date of birth2
, a Personal Public Service
number3
, first and surname and phone number. Once processed you are
provided with a credit union account and the balance of 0.
a) Write a struct to contain the required variables to represent the credit
union account.
b) Write the program that will initialise the first student into the DIT struct
of the credit union template. Use the dot operator on the members
values.
Jane Ferris, 01 402300, DIT, Kevin Street, Dublin2, PPS: 123456X Date of
Birth 1/01/1999.
c) Refine that structure to include two nested structures for the account
holders date of birth and address.
d) Update the program of b) such that the DIT student (Jane) will initialise
and be hardcoded into the program.
e) Alter the code of d) such that the data on the DIT student (Jane) is
written into a file (you select the name & extension).
f) Write a new program reusing any code that will take the data from the
user for the student variable DIT2. This will be saved to file and then
read from the same file and displayed on screen.
