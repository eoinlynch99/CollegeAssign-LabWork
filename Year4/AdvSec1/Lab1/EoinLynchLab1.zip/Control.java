package lab1;

public class Control {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calcGUI labClac = new calcGUI();

	}

}
