<?php

    //This php script opens the database, it is included at the top of every pages that needs to access the database.

    $con = mysqli_connect("localhost", "root", "", "darceair");

?>