***Jack D'Arcy and Eoin Lynch ReadMe Document***

Once the zip file has been downloaded, extract all files into a folder in C:/xampp/htdocs called "Darceair".
It must go into the htdocs section so that the application can be deployed fully
and properly. CSS files have to be put in a "css" folder, photos into an "images" folder
and JavaScript into a "Javascript" folder, all within the "Darceair" folder. Start the XAMPP control panel and start up
Apache and mySQL. To import the database, go to “localhost/phpMyAdmin/” and create a
database named “darceair”. Then click the “Import” button and upload the SQL file which is inside the
ZIP folder for the assignment, and this will insert and populate the necessary 
tables in order for the website to start. 

Then log onto the Internet through whichever browser that’s suitable and navigate
to “localhost/Darceair/” to launch the website. To fully access parts of the website
(Bookings, Faves list), the user must have an account and be logged into it so ensure
to do this also.
